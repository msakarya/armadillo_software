#!/usr/bin/env python
__copyright = 'Copyright (C) 2010 Mustafa Sakarya'
__author__  = 'Mustafa Sakarya mustafasakarya1986@gmail.com'
__license__ = 'GNU GPLv3 http://www.gnu.org/licenses/'

from com import COM
import re
class ADC:
    def __init__(self):
        self.adc=range(32)
    def _parse_adc_(self,data):
        if(data[1]=='n'and(len(data)==18)):
            self.adc=range(8)
            adc_temp=bytearray(data[2:])            
            for i in range(8):
                self.adc[i]=adc_temp[i*2]*256+adc_temp[i*2+1]
        if(data[1]=='d'and(len(data)>18)):
            self.adc=range(32)
            adc_temp=bytearray(data[2:])
            for i in range(32):
                self.adc[i]=adc_temp[i*2]*256+adc_temp[i*2+1]
class SERVO:
    def __init__(self):
        self.s_pos=range(32)
        self.s_velocity=range(32)
        for i in range(32):
            self.s_pos[i]=120
            self.s_velocity[i]=0
    def pack_servo(self,which):
        w=which
        l=[]
        l.append(ord('s'))
        l.append(w)
        l.append(self.s_pos[w])
        l.append(self.s_velocity[w])        
        return l
    def s_set_value(self,which,pos,velocity=None):
        w=which
        self.s_pos[w]=pos
        self.s_velocity[w] = velocity if velocity else 0
        l=self.pack_servo(w)
        self.com.write(l)        
        return l
        
class Armadillo(ADC,SERVO):
    def __init__(self):
        ADC.__init__(self)
        SERVO.__init__(self)
        self._com_=COM(read_cbf=self.parse)
        self.d={}
        self.f={}
        f=self.f
        d=self.d
        d['request_id']="id?\r"
        f['message']=None
        f['seconds']=None
        f['adc']=None
        
    def parse(self,data):
        d=self.d
        f=self.f
        if(data[0]=='s'):
            if(len(data)>12):                
                s=''.join(data)
                s=re.split('[^0-9]', s)
                if(f['seconds']):
                    f['seconds'](s)
        elif(data[0]=='$'):
            s=''.join(data)
            if(f['message']):
                f['message'](s)
        elif(data[0]=='a'): #adc
            self._parse_adc_(data)
            if(f['adc']):
                f['adc'](self.adc)
    def connect(self):
        self._com_.connect()
    def disconnect(self):
        self._com_.disconnect()
    def destroy(self):
        try:
            self._com_.disconnect()
        except:
            pass
    def request_id(self):
        d=self.d
        #print self.com.is_open()
        #if self.com.is_open():
        self._com_.write(d['request_id'])

if __name__=="__main__":
    kit=Armadillo()
    kit.connect()
